package pe.edu.upeu.sysventas.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.sysventas.dto.ComboBoxOption;
import pe.edu.upeu.sysventas.enums.TipoFuncion;
import pe.edu.upeu.sysventas.model.Producto;
import pe.edu.upeu.sysventas.repository.ICrudGenericoRepository;
import pe.edu.upeu.sysventas.repository.ProductoRepository;
import pe.edu.upeu.sysventas.service.IProductoService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class ProductoServiceImp extends  CrudGenericoServiceImp<Producto, Long> implements IProductoService {
    private final ProductoRepository productoRepository;
    @Override
    protected ICrudGenericoRepository<Producto, Long> getRepo() {
        return productoRepository;
    }

    @Override
    public List<ComboBoxOption> listarTipoProducto() {

        List<ComboBoxOption> listar=new ArrayList<>();
        for (TipoFuncion tp: TipoFuncion.values()){
            ComboBoxOption cb=new ComboBoxOption();
            cb.setKey(tp.name());
            cb.setValue(tp.getDescripcion());
            listar.add(cb);
        }
        return listar;
    }

    @Override
    public List<Producto> findAll() {

        if(productoRepository.findAll().isEmpty()){
            productoRepository.seedData();
        }

        return productoRepository.findAll();
    }
}
